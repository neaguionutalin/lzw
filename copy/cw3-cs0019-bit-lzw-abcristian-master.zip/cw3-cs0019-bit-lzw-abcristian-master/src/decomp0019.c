#include "comp0019.h"

void Decode(FILE* in_file, FILE* out_file) {
  // Code goes here.
}

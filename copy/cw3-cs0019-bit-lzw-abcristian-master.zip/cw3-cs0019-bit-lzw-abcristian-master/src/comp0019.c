#include "comp0019.h"

void Encode(FILE* in_file, FILE* out_file) {
  // Code goes here.
}

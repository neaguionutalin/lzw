#include "comp0019lib.h"

// Remove this when you add any functions.
typedef int make_iso_compilers_happy;
